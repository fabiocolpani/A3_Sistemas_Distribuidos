package com.exemplo.boleto.repository;

import com.exemplo.boleto.model.Boleto;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BoletoRepository extends JpaRepository<Boleto, String> {
}
