package com.exemplo.boleto.controller;

import com.exemplo.boleto.model.Boleto;
import com.exemplo.boleto.repository.BoletoRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/boletosnew")
@CrossOrigin(origins = "*")
public class BoletoController {

    private final BoletoRepository boletoRepository;

    public BoletoController(BoletoRepository boletoRepository) {
        this.boletoRepository = boletoRepository;
    }

    @PostMapping
    public Boleto cadastrar(@RequestBody Boleto boleto) {
        return boletoRepository.save(boleto);
    }

    @GetMapping("/{codCnpj}")
    public ResponseEntity<Boleto> buscarPorCodigo(@PathVariable String codCnpj) {
        return boletoRepository.findById(codCnpj)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping
    public List<Boleto> listarTodos() {
        return boletoRepository.findAll();
    }
}
