package com.exemplo.boleto.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Boleto {

    @Id
    private String codCnpj;
    private String descricao;
    private String nomeGolpista;
    private String data;

    public String getCodCnpj() { return codCnpj; }
    public void setCodCnpj(String codCnpj) { this.codCnpj = codCnpj; }

    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }

    public String getNomeGolpista() { return nomeGolpista; }
    public void setNomeGolpista(String nomeGolpista) { this.nomeGolpista = nomeGolpista; }

    public String getData() { return data; }
    public void setData(String data) { this.data = data; }
}
