package com.exemplo.boleto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoletoGolpistaApplication {
    public static void main(String[] args) {
        SpringApplication.run(BoletoGolpistaApplication.class, args);
    }
}
