# Boleto Golpista API (com banco de dados MySQL)

## 📌 Descrição
API para registrar boletos suspeitos de golpe, com persistência em banco de dados MySQL.

## Tecnologias
- Java 17
- Spring Boot
- Spring Data JPA
- MySQL

## Endpoints

- POST `/boletos` → cadastra um boleto suspeito
- GET `/boletos/{codigoBarras}` → busca boleto pelo código de barras
- GET `/boletos` → lista todos os boletos cadastrados

## Como rodar
1. Crie o banco de dados:
    ```sql
    CREATE DATABASE banco_golpes;
    ```

2. Configure o `application.properties` com seu usuário e senha do MySQL.

3. No terminal:
    ```bash
    ./mvnw spring-boot:run
    ```
    ou
    ```bash
    mvn spring-boot:run
    ```

## Observação
Os dados ficam persistidos no banco MySQL.
